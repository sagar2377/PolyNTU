<!-- TODO: Embed or link the PolyNTU design class diagram (boundary, control, entity classes). -->
<!-- TODO: Add the class responsibility matrix: one row per class with its responsibilities. -->
<!-- TODO: Add use-case mappings: which boundary and control classes realise each use case. -->
<!-- TODO: List all control-to-entity dependencies, including the minor ones omitted from the diagram. -->
<!-- TODO: Map each diagram class to its source file in backend/ or frontend/. -->
