// TODO: CreateMarketPage <<boundary>> - market creation UI.
// TODO: enterDefinition(): form for title, resolution criterion, rule, source, outcomes, recurrence.
// TODO: prepareResolutionAuthority(): choose and configure who or what resolves the market.
// TODO: publishMarket(): submit to MarketCreationControl via the backend API.
