// TODO: AccountPanel <<boundary>> - account UI.
// TODO: registerAccount(): registration form; calls AccountControl via the backend API.
// TODO: logIn(): login form; calls AccountControl.authenticate.
// TODO: requestCreatorVerification(): button to request creator status.
// TODO: signOutLocally(): clear the local session without a backend call.
