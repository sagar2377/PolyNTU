// TODO: PortfolioPage <<boundary>> - user holdings UI.
// TODO: showPositionsAndCredits(): list positions and settlement credits (PortfolioControl).
// TODO: showTradeHistory(): list past trades (PortfolioControl).
