// TODO: MarketBrowsePage <<boundary>> - market discovery UI.
// TODO: selectCategory(): filter markets by category.
// TODO: browseHistory(): view past and resolved instances.
// TODO: openMarket(): navigate to MarketPage for a chosen instance.
// TODO: Data comes from MarketQueryControl via the backend API.
