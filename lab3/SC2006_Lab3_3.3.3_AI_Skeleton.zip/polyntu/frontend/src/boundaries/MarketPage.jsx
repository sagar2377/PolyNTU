// TODO: MarketPage <<boundary>> - single market UI.
// TODO: showMarketAndCharts(): display instance, outcomes and probability charts (MarketQueryControl).
// TODO: previewAndConfirmTrade(): show a quote then confirm the trade (TradingControl).
// TODO: resumePendingTrade(): recover the receipt of an unacknowledged trade (TradingControl).
// TODO: signAndSubmitResolution(): creator submits a signed resolution (MarketLifecycleControl).
