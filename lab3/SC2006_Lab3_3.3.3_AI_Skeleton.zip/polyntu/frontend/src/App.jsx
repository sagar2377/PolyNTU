// TODO: Root component: set up routing to each boundary page.
// TODO: Routes: account (AccountPanel), browse (MarketBrowsePage), market detail (MarketPage), create market (CreateMarketPage), portfolio (PortfolioPage).
// TODO: Hold the signed-in session so pages know who is viewing.
