// TODO: Frontend entry point: mount <App /> into the root element.
