// TODO: Build tool configuration for the React app.
// TODO: Dev-server proxy to the Rust backend's HTTP API.
