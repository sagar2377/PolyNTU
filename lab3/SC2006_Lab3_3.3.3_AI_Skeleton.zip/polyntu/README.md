<!-- TODO: Project overview for PolyNTU, a campus prediction-market web application. -->
<!-- TODO: Explain the repo layout: backend/ (Rust), frontend/ (React + JavaScript), docs/. -->
<!-- TODO: Explain the boundary / control / entity split and where each lives. -->
<!-- TODO: Add local setup, run and test instructions once the stack is wired up. -->
