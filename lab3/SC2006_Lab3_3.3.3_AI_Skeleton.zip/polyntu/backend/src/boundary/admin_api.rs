// TODO: AdminApi <<boundary>> - administrator API (an API, not an admin screen).
// TODO: receiveAdminRequest(): accept and authenticate an incoming admin request and route it to AdminControl.
// TODO: returnResult(): serialise the AdminControl outcome back to the administrator.
// TODO: Depends on AdminControl.
