// TODO: ResolverGateway <<boundary>> - interface to the external resolution API.
// TODO: requestExternalResolution(): call the external API for a market instance's source and event.
// TODO: parseResolverResponse(): convert the external response into Evidence data for MarketLifecycleControl.
// TODO: Used by MarketLifecycleControl.
