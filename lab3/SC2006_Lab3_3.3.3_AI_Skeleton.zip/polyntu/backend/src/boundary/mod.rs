// TODO: Boundary module: interfaces to actors outside the core system.
// TODO: Expose admin_api and resolver_gateway submodules.
