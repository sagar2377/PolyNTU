// TODO: Entity module: domain data and associations.
// TODO: Expose one submodule per entity.
// TODO: Decide where shared value types live (Identifier, Money, Quantity, Timestamp, and the Kind / State / Rule enums).
