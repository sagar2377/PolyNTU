// TODO: Outcome <<entity>>.
// TODO: Attributes: outcomeId: String, index: Integer, label: String, outstandingShares: Quantity, /probability: Decimal (derived, not stored).
// TODO: Associations: part of exactly 1 MarketInstance; traded outcome of 0..* Trades; held outcome of 0..* Positions.
