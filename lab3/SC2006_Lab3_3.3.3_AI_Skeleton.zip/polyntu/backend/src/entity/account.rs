// TODO: Account <<entity>>.
// TODO: Attributes: accountId: Identifier, displayName: String, kind: AccountKind, email: String [0..1], role: AccountRole [0..1], passwordHash: String [0..1], tokenHash: String [0..1], balance: Money.
// TODO: Associations: requester of 0..* VerificationRequest; creator of 0..* MarketSeries; from/to of 0..* LedgerTransfer; recipient of 0..* SettlementClaim; trader of 0..* Trade; holder of 0..* Position; reserve for 0..1 MarketInstance.
