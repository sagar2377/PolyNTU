// TODO: MarketSeries <<entity>>.
// TODO: Attributes: seriesId: Identifier, title: String, resolutionCriterion: String, rule: MarketRule, sourceId: String, dataMode: DataMode, liquidityUnits: Integer, feeCharged: Boolean, recurrence: RecurrenceKind, schedule: RecurrencePolicy [0..1], resolutionAuthority: AuthorityKind, resolverConfig: ResolverConfig [0..1], resolutionKey: ResolutionKey [0..1], state: SeriesState.
// TODO: Associations: 0..1 creator Account; groups 0..* MarketInstance.
