// TODO: SettlementClaim <<entity>>.
// TODO: Attributes: creditedAmount: Money, settledAt: Timestamp.
// TODO: Associations: exactly 1 recipient Account; MarketInstance pays 0..* claims.
