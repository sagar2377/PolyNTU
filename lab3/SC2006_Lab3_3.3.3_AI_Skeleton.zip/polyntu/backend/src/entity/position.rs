// TODO: Position <<entity>>.
// TODO: Attributes: quantity: Quantity.
// TODO: Associations: exactly 1 holder Account; exactly 1 held Outcome.
