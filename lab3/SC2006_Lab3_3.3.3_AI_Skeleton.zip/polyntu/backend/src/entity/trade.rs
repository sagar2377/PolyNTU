// TODO: Trade <<entity>>.
// TODO: Attributes: tradeId: Identifier, side: TradeSide, quantity: Quantity, allInAmount: Money, feeAmount: Money, instanceVersion: Integer, executedAt: Timestamp.
// TODO: Associations: exactly 1 trader Account; exactly 1 traded Outcome.
