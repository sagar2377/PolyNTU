// TODO: LedgerTransfer <<entity>>.
// TODO: Attributes: transferId: Identifier, amount: Money, kind: TransferKind, reference: String, createdAt: Timestamp.
// TODO: Associations: from exactly 1 Account, to exactly 1 Account.
