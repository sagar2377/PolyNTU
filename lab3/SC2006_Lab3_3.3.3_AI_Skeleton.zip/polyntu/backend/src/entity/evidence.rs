// TODO: Evidence <<entity>>.
// TODO: Attributes: evidenceId: Identifier, sourceId: String, eventId: String, sourceRevision: Integer, receivedAt: Timestamp, payload: EvidencePayload, evaluatedResult: Resolution [0..1].
// TODO: Associations: revision of exactly 1 MarketInstance.
