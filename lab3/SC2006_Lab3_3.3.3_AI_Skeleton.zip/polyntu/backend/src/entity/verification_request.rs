// TODO: VerificationRequest <<entity>>.
// TODO: Attributes: requestId: Identifier, status: VerificationStatus, reason: String [0..1], requestedAt: Timestamp, decidedAt: Timestamp [0..1].
// TODO: Associations: 0..* requests by exactly 1 requester Account.
