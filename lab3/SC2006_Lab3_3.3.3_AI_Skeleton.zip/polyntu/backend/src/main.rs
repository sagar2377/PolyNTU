// TODO: Backend entry point.
// TODO: Declare the boundary, control and entity modules.
// TODO: Load configuration, initialise the database connection and start the HTTP server.
// TODO: Register HTTP routes that the frontend boundary pages call, delegating to the control layer.
// TODO: Mount the AdminApi boundary routes.
// TODO: Start the scheduled job that drives MarketLifecycleControl (spawning brackets, closing, voiding at deadline).
