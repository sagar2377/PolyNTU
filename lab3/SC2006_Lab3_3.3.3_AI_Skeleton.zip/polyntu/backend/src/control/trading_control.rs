// TODO: TradingControl <<control>> - coordinates buying and selling outcome shares.
// TODO: issueQuote(): price a proposed trade from the instance's outcomes and liquidity, including fees.
// TODO: executeTrade(): validate balance and instance version, record a Trade, update Position and Outcome shares, adjust Account balance.
// TODO: recoverReceipt(): return the receipt of a trade that was submitted but not acknowledged.
// TODO: Depends on Trade, Position (and Account, MarketInstance, Outcome via the responsibility matrix).
// TODO: Called by MarketPage.
