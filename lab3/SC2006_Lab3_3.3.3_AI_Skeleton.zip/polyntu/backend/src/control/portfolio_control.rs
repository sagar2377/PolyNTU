// TODO: PortfolioControl <<control>> - a user's holdings.
// TODO: getPositionsAndCredits(): return the account's Positions and SettlementClaims.
// TODO: getTradeHistory(): return the account's Trades.
// TODO: Depends on Position. Called by PortfolioPage.
