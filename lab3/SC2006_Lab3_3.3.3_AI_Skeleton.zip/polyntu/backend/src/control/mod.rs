// TODO: Control module: use-case coordination logic.
// TODO: Expose trading, admin, account, market_creation, market_query, market_lifecycle and portfolio submodules.
