// TODO: MarketCreationControl <<control>> - creating markets.
// TODO: validateDefinitionAndAuthority(): check the market definition and the creator's resolution authority.
// TODO: publishSeries(): persist a MarketSeries in its initial state.
// TODO: fundOneTimeInstance(): create and fund a one-time MarketInstance from the creator's reserve.
// TODO: Depends on MarketSeries. Called by CreateMarketPage.
