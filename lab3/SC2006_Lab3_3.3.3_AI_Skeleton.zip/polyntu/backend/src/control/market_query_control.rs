// TODO: MarketQueryControl <<control>> - read-only market queries.
// TODO: listMarkets(): list instances filtered by category and state.
// TODO: getMarketAndSeries(): fetch a MarketInstance with its MarketSeries and Outcomes.
// TODO: getHistoryAndDayProbabilities(): return past instances and per-day outcome probabilities for charts.
// TODO: Depends on MarketInstance. Called by MarketPage and MarketBrowsePage.
