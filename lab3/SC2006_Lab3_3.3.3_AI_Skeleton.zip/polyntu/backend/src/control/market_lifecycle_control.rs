// TODO: MarketLifecycleControl <<control>> - scheduled and resolution-driven lifecycle.
// TODO: spawnDueBrackets(): create new MarketInstances for recurring series whose schedule is due.
// TODO: closeDueInstances(): close trading on instances whose window has ended.
// TODO: acceptSignedResolution(): accept a creator-signed resolution from MarketPage.
// TODO: resolveAutomatically(): fetch Evidence through ResolverGateway and evaluate the result.
// TODO: settleAndSplitFees(): create SettlementClaims for winning positions and split fees.
// TODO: voidAtDeadline(): void unresolved instances past their deadline and refund.
// TODO: Depends on Account, Evidence; calls external API via ResolverGateway.
