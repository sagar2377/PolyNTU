// TODO: AccountControl <<control>> - account lifecycle.
// TODO: registerAndGrantWelcomeGift(): create an Account and record the welcome-gift LedgerTransfer.
// TODO: authenticate(): verify credentials against passwordHash and issue a session token.
// TODO: requestCreatorVerification(): create a pending VerificationRequest for the account.
// TODO: Depends on Account, VerificationRequest. Called by AccountPanel.
