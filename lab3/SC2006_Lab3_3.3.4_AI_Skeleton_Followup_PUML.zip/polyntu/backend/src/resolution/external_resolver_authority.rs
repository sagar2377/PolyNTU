// TODO: ExternalResolverAuthority <<strategy>> - accepts evidence obtained through ResolverGateway.
