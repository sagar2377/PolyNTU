// TODO: AdminAuthority <<strategy>> - accepts evidence submitted by an administrator.
