// TODO: CreatorSignedAuthority <<strategy>> - accepts resolutions signed with the series' resolutionKey.
// TODO: Verify the creator's signature before accepting.
