// TODO: ResolutionAuthority <<strategy>> interface.
// TODO: acceptEvidence: decide whether submitted evidence resolves a MarketInstance.
// TODO: MarketLifecycleControl selects the implementation from the series' resolutionAuthority.
