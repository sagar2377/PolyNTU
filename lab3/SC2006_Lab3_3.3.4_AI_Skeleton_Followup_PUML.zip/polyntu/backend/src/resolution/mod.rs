// TODO: Declare the ResolutionAuthority strategy and its three implementations.
