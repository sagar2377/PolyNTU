// TODO: BackgroundWorker <<active>> - scheduled processing task.
// TODO: run: loop and call tick on an interval.
// TODO: tick: drive MarketLifecycleControl (spawn, close, resolve, settle, void, purge).
// TODO: seedDemo: insert demo data for development.
