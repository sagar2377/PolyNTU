// TODO: EventBus <<infrastructure>> - in-process publish/subscribe channels shared via AppState.
// TODO: subscribe: return a receiver for market/trade events.
