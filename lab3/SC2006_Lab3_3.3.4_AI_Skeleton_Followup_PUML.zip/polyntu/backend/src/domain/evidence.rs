// TODO: Evidence <<entity>>
// TODO: Attributes: evidenceId, sourceId, eventId, sourceRevision, receivedAt, payload, evaluatedResult?.
// TODO: Many revisions per MarketInstance.
