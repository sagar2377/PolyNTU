// TODO: TradeHistory <<container>> - an Account's trades.
// TODO: append, page.
