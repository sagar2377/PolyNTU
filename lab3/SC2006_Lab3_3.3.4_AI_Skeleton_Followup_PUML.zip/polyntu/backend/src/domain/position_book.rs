// TODO: PositionBook <<container>> - an Account's holdings.
// TODO: quantityOf, openHoldings, adjust.
