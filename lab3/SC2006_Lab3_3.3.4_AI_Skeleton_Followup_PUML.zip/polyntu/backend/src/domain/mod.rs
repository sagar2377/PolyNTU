// TODO: Declare entity and container submodules.
// TODO: Shared value types referenced by the diagram (Identifier, Money, Quantity, Timestamp, enums) need a home here or in a dedicated submodule.
