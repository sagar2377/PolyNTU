// TODO: OutcomeSet <<container>> - owns the rules for a market's 2..8 Outcomes.
// TODO: indexOf, prices, validate.
