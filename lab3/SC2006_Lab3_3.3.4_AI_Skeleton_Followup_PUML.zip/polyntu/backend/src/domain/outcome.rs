// TODO: Outcome <<entity>>
// TODO: Attributes: outcomeId, index, label, outstandingShares, derived probability.
// TODO: Referenced by Positions and Trades.
