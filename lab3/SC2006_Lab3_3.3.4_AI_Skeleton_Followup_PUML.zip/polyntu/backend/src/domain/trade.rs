// TODO: Trade <<entity>>
// TODO: Attributes: tradeId, side, quantity, allInAmount, feeAmount, instanceVersion, executedAt.
// TODO: Belongs to a TradeHistory; refers to one Outcome.
