// TODO: LedgerTransfer <<entity>>
// TODO: Attributes: transferId, amount, kind, reference, createdAt.
// TODO: Has a 'from' Account and a 'to' Account.
