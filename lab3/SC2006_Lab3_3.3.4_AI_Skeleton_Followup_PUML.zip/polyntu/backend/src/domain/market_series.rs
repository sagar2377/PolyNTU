// TODO: MarketSeries <<entity>>
// TODO: Attributes: seriesId, title, resolutionCriterion, rule, sourceId, dataMode, liquidityUnits, feeCharged, recurrence, schedule?, resolutionAuthority, resolverConfig?, resolutionKey?, state.
// TODO: isActiveAt, bracketSpec.
// TODO: Optional creator Account; groups many MarketInstances.
