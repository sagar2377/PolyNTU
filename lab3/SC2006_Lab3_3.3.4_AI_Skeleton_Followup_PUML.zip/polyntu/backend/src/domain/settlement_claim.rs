// TODO: SettlementClaim <<entity>>
// TODO: Attributes: creditedAmount, settledAt.
// TODO: Links a MarketInstance payout to a recipient Account.
