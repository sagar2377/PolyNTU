// TODO: VerificationRequest <<entity>>
// TODO: Attributes: requestId, status, reason?, requestedAt, decidedAt?.
// TODO: isPending, approve, reject.
// TODO: One Account (requester) to many requests.
