// TODO: Account <<entity>>
// TODO: Attributes: accountId, displayName, kind, email?, role?, passwordHash?, tokenHash?, balance.
// TODO: verifyPassword, hasRole, canAfford.
// TODO: Owns one PositionBook and one TradeHistory (composition).
