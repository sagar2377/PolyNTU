// TODO: MarketInstance <<entity>>
// TODO: Attributes: instanceId, title, resolutionCriterion, rule, sourceId, dataMode, state, suspended, window, bracketStart?, liquidityUnits, feeCharged, creatorId?, version, result?, selectedEvidence?.
// TODO: isTradable, isCreatedBy, isObservationOver, isPastEvidenceDeadline.
// TODO: Composes one OutcomeSet; has Evidence revisions and SettlementClaims; funded from a reserve Account.
