// TODO: Position <<entity>>
// TODO: Attributes: quantity.
// TODO: isOpen.
// TODO: Belongs to a PositionBook; refers to one Outcome.
