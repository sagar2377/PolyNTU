// TODO: Declare the router and admin_api submodules.
// TODO: Browser-to-control HTTP handlers live here; one handler group per frontend page.
