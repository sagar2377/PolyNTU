// TODO: ApiRouter <<boundary>> - builds the HTTP router at startup.
// TODO: router: register routes for account, market browse, market creation, market page, portfolio and admin endpoints.
// TODO: Attach AppState and any auth middleware.
