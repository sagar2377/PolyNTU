// TODO: AdminApi <<boundary>> - HTTP API for administrators (an API, not an admin screen).
// TODO: receiveAdminRequest: parse the admin request and delegate to AdminControl.
// TODO: returnResult: map the AdminControl result or error to an HTTP response.
