// TODO: ResolverGateway <<boundary>> - client for external resolvers over the HTTP resolver contract.
// TODO: requestExternalResolution: call the configured resolver.
// TODO: parseResolverResponse: turn the response into Evidence.
