// TODO: Declare resolver_gateway and ntu_bus_adapter submodules.
