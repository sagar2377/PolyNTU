// TODO: NtuBusAdapter <<boundary>> - resolver for NTU shuttle-bus data behind the HTTP resolver contract.
// TODO: answer: respond to a resolver request with evidence.
// TODO: Decide whether this runs in-process or as a separate service.
