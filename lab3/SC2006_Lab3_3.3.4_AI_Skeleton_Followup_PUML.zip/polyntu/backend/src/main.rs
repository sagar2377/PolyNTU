// TODO: StartupControl <<control>> - program entry point (main).
// TODO: Declare the top-level modules: store, app_state, api, controls, domain, resolution, integrations, runtime.
// TODO: Connect and initialise the Store.
// TODO: Create the EventBus and construct AppState from the Store and EventBus.
// TODO: Configure the ApiRouter and start serving HTTP.
// TODO: Seed demo data and start the BackgroundWorker.
// TODO: Start the EventRuntime listener and clock refresher.
// TODO: On shutdown, stop the BackgroundWorker and EventRuntime cleanly.
