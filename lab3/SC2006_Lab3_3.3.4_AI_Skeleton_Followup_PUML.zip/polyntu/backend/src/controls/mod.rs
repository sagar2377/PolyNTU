// TODO: Declare the seven use-case control submodules.
