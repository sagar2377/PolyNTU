// TODO: MarketCreationControl <<control>> - market creation (CreateMarketPage, AdminControl, MarketLifecycleControl).
// TODO: validateDefinitionAndAuthority: check rule, outcomes (2..8), schedule and resolution authority.
// TODO: publishSeries: persist a new MarketSeries.
// TODO: createFundedInstance: create a MarketInstance funded from the reserve Account.
