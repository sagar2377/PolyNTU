// TODO: MarketLifecycleControl <<control>> - market lifecycle (BackgroundWorker, MarketPage, AdminControl).
// TODO: spawnDueBrackets: create due recurring instances via MarketCreationControl.
// TODO: closeDueInstances: close trading when the market window ends.
// TODO: acceptAdminEvidence / acceptSignedResolution: route evidence to the series' ResolutionAuthority.
// TODO: resolveAutomatically: request resolution via ResolverGateway for external-resolver series.
// TODO: setSuspension: suspend or resume trading on an instance.
// TODO: settleAndSplitFees: create SettlementClaims and fee LedgerTransfers.
// TODO: voidAtDeadline: void instances past the evidence deadline and refund.
// TODO: purgeExpiredBrackets: remove expired, unused bracket instances.
