// TODO: TradingControl <<control>> - trading (MarketPage).
// TODO: issueQuote: price a proposed trade against the current OutcomeSet.
// TODO: executeTrade: re-check the instance version, update PositionBook and TradeHistory, record fees and transfers atomically.
// TODO: recoverReceipt: return the receipt for a pending/resumed trade.
