// TODO: MarketQueryControl <<control>> - read-only market queries (MarketBrowsePage, MarketPage).
// TODO: listMarkets: list MarketInstances by category, paged, including history.
// TODO: getMarket: return one MarketInstance with its OutcomeSet and prices.
// TODO: getSeries: return a MarketSeries and its instances.
// TODO: getHistory: return price/trade history for charts.
