// TODO: AccountControl <<control>> - account use cases (used by AccountPanel).
// TODO: registerAndGrantWelcomeGift: create an Account and record the welcome LedgerTransfer.
// TODO: authenticate: verify credentials and issue a session token.
// TODO: getCurrentAccount: return the signed-in Account.
// TODO: requestCreatorVerification: create a pending VerificationRequest.
// TODO: getVerificationStatus: return the latest VerificationRequest status.
