// TODO: PortfolioControl <<control>> - portfolio views (PortfolioPage).
// TODO: getPositionsAndCredits: return open PositionBook holdings and balance.
// TODO: getTradeHistory: return a page of TradeHistory.
