// TODO: AppState <<infrastructure>> - shared state handed to every request handler.
// TODO: new: build from the Store's pool and cache and the EventBus channels.
// TODO: account: resolve the current Account from the request's session token.
// TODO: requireAdmin: reject the request unless the account has the admin role.
