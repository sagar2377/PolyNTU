// TODO: Store <<infrastructure>> - shared database pool and cache.
// TODO: connect: open the database connection pool.
// TODO: now: return the current timestamp from a single authoritative clock.
// TODO: initialize (private): apply schema / migrations on startup.
