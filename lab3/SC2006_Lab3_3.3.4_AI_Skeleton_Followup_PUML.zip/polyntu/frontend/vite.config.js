// TODO: Bundler configuration, including the dev proxy to the backend API.
