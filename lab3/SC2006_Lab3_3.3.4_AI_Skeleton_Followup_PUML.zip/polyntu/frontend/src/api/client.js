// TODO: Thin HTTP client for the backend API; one function group per control the pages call.
// TODO: Handle session-expired responses centrally.
