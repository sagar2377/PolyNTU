// TODO: Top-level component: routing between pages and the AccountPanel.
