// TODO: MarketBrowsePage <<boundary>> -> MarketQueryControl.
// TODO: selectCategory, openHistoryTab, turnPage, openMarket.
