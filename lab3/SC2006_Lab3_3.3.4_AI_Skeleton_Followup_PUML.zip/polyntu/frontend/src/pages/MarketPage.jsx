// TODO: MarketPage <<boundary>> -> MarketQueryControl, TradingControl, MarketLifecycleControl.
// TODO: showMarketAndCharts, selectBracket, previewTrade, confirmTrade, resumePendingTrade.
// TODO: deriveSigningKey, signAndSubmitResolution.
