// TODO: CreateMarketPage <<boundary>> -> MarketCreationControl.
// TODO: enterDefinition, chooseResolutionAuthority, deriveSigningKey, publishMarket.
