// TODO: PortfolioPage <<boundary>> -> PortfolioControl.
// TODO: showPositionsAndCredits, showTradeHistory, openMarket.
