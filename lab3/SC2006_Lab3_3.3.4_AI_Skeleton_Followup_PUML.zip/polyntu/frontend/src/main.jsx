// TODO: Entry point: mount App into the root element.
